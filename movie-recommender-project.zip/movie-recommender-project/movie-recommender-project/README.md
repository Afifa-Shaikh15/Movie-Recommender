# Movie Recommendation System (Python · Pandas · scikit-learn · Streamlit)

A hybrid movie recommender that combines **item-based collaborative filtering** (from user ratings)
with **content-based filtering** (from movie genres). Optional **sentiment re-ranking** is supported
if you provide a reviews dataset.

## Features
- Uses MovieLens dataset (default: `ml-latest-small`).
- Preprocess & clean MovieLens movies and ratings.
- Item–Item Collaborative Filtering with cosine similarity on rating vectors.
- Content-based filtering using genres (TF-IDF or multi-hot vectorization).
- Hybrid scoring: `score = α * CF + (1-α) * Content`.
- Streamlit UI to select favorite movies & preferred genres; returns Top-5 recommendations.
- Optional sentiment-based adjustment using VADER if `reviews.csv` exists.
- Deliverables: **Notebook**, **Streamlit UI**, **recommender logic**.

## Quick Start
```bash
# 1) Create a virtual environment (recommended)
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate

# 2) Install dependencies
pip install -r requirements.txt

# 3) (Optional) Download MovieLens 'ml-latest-small'
# The app will try to auto-download; or download manually from:
# https://files.grouplens.org/datasets/movielens/ml-latest-small.zip
# Unzip so that you have:
#   data/ml-latest-small/movies.csv
#   data/ml-latest-small/ratings.csv

# 4) Run Streamlit app
streamlit run app.py

# 5) Explore the notebook
jupyter notebook notebooks/movielens_recommender.ipynb
```

## Project Structure
```
movie-recommender-project/
├─ app.py                      # Streamlit UI
├─ recommender.py              # Core recommendation logic (hybrid model)
├─ requirements.txt
├─ README.md
├─ data/
│  └─ (place MovieLens here) ml-latest-small/{movies.csv,ratings.csv}
└─ notebooks/
   └─ movielens_recommender.ipynb
```

## Optional: Sentiment Re-Ranking
Place a file at `data/reviews.csv` with columns: `movieId,title,review_text` (review_text is free text).
The app will use VADER to compute sentiment polarity per movie and give a mild boost to positively-reviewed titles.

## Notes
- Everything runs on **pandas** and **scikit-learn**; no Surprise dependency required.
- The CF part uses **item–item** similarity so you can generate recommendations from a few liked movies without a user history.
- This project is designed to be simple, readable, and easily extensible.
