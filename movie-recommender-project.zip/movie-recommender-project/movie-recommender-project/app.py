import streamlit as st
from pathlib import Path
import pandas as pd
from recommender import load_dataframes, recommend_hybrid, search_titles

st.set_page_config(page_title="Movie Recommender", layout="wide")
st.title("🎬 Movie Recommendation System")

data_dir = Path("data")

@st.cache_data(show_spinner=True)
def load_data():
    movies, ratings = load_dataframes(data_dir)
    return movies, ratings

with st.sidebar:
    st.header("Settings")
    alpha = st.slider("Hybrid Weight (CF vs Content)", min_value=0.0, max_value=1.0, value=0.6, step=0.05)
    top_n = st.number_input("Top-N Recommendations", min_value=1, max_value=20, value=5, step=1)
    categories = ["All", "Bollywood", "Hollywood", "Hindi"]
    selected_category = st.selectbox("Select movie category", categories)
    st.caption("Optional: sentiment re-ranking if data/reviews.csv is present.")

movies, ratings = load_data()
if selected_category != "All":
    movies = movies[movies['category'].str.lower() == selected_category.lower()]

st.subheader("Pick your favorite movies")
col1, col2 = st.columns(2)

with col1:
    query = st.text_input("Search a movie to add (substring search)", value="Toy Story")
    if query:
        results = search_titles(movies, query)
        st.dataframe(results, width="stretch")

with col2:
    liked_titles = st.text_area("Enter liked movie titles (one per line)", value="Toy Story\nJumanji")
    genres_all = sorted({g for lst in movies["genres_list"] for g in (lst or []) if g})
    preferred_genres = st.multiselect("Preferred genres (optional)", genres_all, default=[])

st.subheader("Add a New Movie")
with st.form(key='add_movie_form'):
    new_title = st.text_input("Movie Title")
    new_genres = st.text_input("Genres (pipe-separated)")
    new_category = st.selectbox("Category", ["Bollywood", "Hollywood"])  # Hindi removed
    submit_button = st.form_submit_button("Add Movie")

if submit_button and new_title and new_genres:
    # Ensure movieId is numeric
    movies['movieId'] = pd.to_numeric(movies['movieId'], errors='coerce').fillna(0).astype(int)
    new_id = movies['movieId'].max() + 1
    new_movie = pd.DataFrame([[new_id, new_title, new_genres, new_category]], columns=['movieId','title','genres','category'])
    movies = pd.concat([movies, new_movie], ignore_index=True)
    movies.to_csv(data_dir / 'ml-latest-small' / 'movies.csv', index=False)
    st.success(f"Added new movie: {new_title}")

if st.button("Get Recommendations"):
    try:
        liked = [t for t in (liked_titles.splitlines() if liked_titles else []) if t.strip()]
        recs = recommend_hybrid(
            movies, ratings,
            liked_titles=liked,
            preferred_genres=preferred_genres if preferred_genres else None,
            top_n=top_n,
            alpha=alpha,
            data_dir=data_dir,
            category_filter=None if selected_category=="All" else selected_category
        )
        st.success(f"Top {len(recs)} recommendations")
        st.dataframe(recs, width="stretch")
    except Exception as e:
        st.error(str(e))

st.markdown("---")
st.caption("Data: MovieLens (ml-latest-small). CF: item-item cosine. Content: genres TF-IDF. Sentiment-based filtering applied if reviews.csv exists.")
