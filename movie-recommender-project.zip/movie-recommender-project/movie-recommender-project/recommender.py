import os
import warnings
import zipfile
from pathlib import Path
from typing import List, Optional, Tuple

import numpy as np
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import MultiLabelBinarizer
import requests

# -------------------------------
# Data Loading / Preparation
# -------------------------------

MOVIELENS_URL = "https://files.grouplens.org/datasets/movielens/ml-latest-small.zip"

def ensure_movielens_data(data_dir: Path) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Ensures MovieLens (ml-latest-small) is available under data_dir.
    Returns (movies, ratings) DataFrames.
    """
    data_dir = Path(data_dir)
    ml_dir = data_dir / "ml-latest-small"
    movies_csv = ml_dir / "movies.csv"
    ratings_csv = ml_dir / "ratings.csv"

    if not movies_csv.exists() or not ratings_csv.exists():
        data_dir.mkdir(parents=True, exist_ok=True)
        zip_path = data_dir / "ml-latest-small.zip"
        try:
            r = requests.get(MOVIELENS_URL, timeout=60)
            r.raise_for_status()
            zip_path.write_bytes(r.content)
            with zipfile.ZipFile(zip_path, "r") as zf:
                zf.extractall(data_dir)
        except Exception as e:
            warnings.warn(
                f"Could not auto-download MovieLens. Please download manually:\\n{MOVIELENS_URL}\\n"
                f"Error: {e}"
            )

    if not movies_csv.exists() or not ratings_csv.exists():
        raise FileNotFoundError(
            "MovieLens files not found. Ensure data/ml-latest-small/movies.csv and ratings.csv exist."
        )

    movies = pd.read_csv(movies_csv)
    ratings = pd.read_csv(ratings_csv)
    return movies, ratings

def clean_movies(movies: pd.DataFrame) -> pd.DataFrame:
    movies = movies.copy()
    # Normalize titles (strip year in parentheses for matching convenience)
    movies["title_clean"] = movies["title"].str.replace(r"\\s*\\(\\d{4}\\)$", "", regex=True)
    # Split genres
    movies["genres_list"] = movies["genres"].replace("(no genres listed)", "", regex=False).str.split("|")
    return movies

def build_item_item_cf(ratings: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Build an item–item cosine similarity matrix from user-item ratings.
    Returns (item_factors (movieId -> vector index), similarity_matrix as DataFrame).
    """
    # Create user-item matrix
    user_item = ratings.pivot_table(index="userId", columns="movieId", values="rating", fill_value=0.0)
    # Compute cosine similarity between items (columns)
    item_vectors = user_item.values.T  # shape: n_items x n_users
    sim = cosine_similarity(item_vectors)
    item_ids = user_item.columns.to_list()
    sim_df = pd.DataFrame(sim, index=item_ids, columns=item_ids)
    return user_item.columns.to_frame(index=False), sim_df

def build_content_vectors(movies: pd.DataFrame, mode: str = "tfidf") -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Build content vectors from genres using either TF-IDF on joined tokens (default) or MultiLabelBinarizer.
    Returns (movie_factors (movieId -> index), content_matrix as DataFrame).
    """
    movies = movies.copy()
    if mode == "tfidf":
        # Join genres into space-separated tokens for TF-IDF
        genre_text = movies["genres_list"].apply(lambda lst: " ".join([g.replace('-', '').replace(' ', '') for g in (lst or [])]))
        tfidf = TfidfVectorizer(token_pattern=r"[^ ]+")
        X = tfidf.fit_transform(genre_text)
        sim = cosine_similarity(X)
        sim_df = pd.DataFrame(sim, index=movies["movieId"], columns=movies["movieId"])
    else:
        mlb = MultiLabelBinarizer()
        X = mlb.fit_transform(movies["genres_list"].apply(lambda x: x or []))
        sim = cosine_similarity(X)
        sim_df = pd.DataFrame(sim, index=movies["movieId"], columns=movies["movieId"])
    return movies[["movieId"]], sim_df

# -------------------------------
# Sentiment (Optional)
# -------------------------------

def load_reviews_if_available(data_dir: Path) -> Optional[pd.DataFrame]:
    """
    Load optional reviews.csv with columns: movieId,title,review_text
    Returns DataFrame with sentiment score per movie if available, else None.
    """
    reviews_path = Path(data_dir) / "reviews.csv"
    if not reviews_path.exists():
        return None
    try:
        import nltk
        from nltk.sentiment import SentimentIntensityAnalyzer
        # Ensure VADER lexicon
        try:
            nltk.data.find('sentiment/vader_lexicon.zip')
        except LookupError:
            nltk.download('vader_lexicon')
        sia = SentimentIntensityAnalyzer()
    except Exception as e:
        warnings.warn(f"NLTK/Sentiment not available: {e}")
        return None

    df = pd.read_csv(reviews_path)
    df = df.dropna(subset=["review_text"])
    df["sentiment"] = df["review_text"].astype(str).apply(lambda t: sia.polarity_scores(t)["compound"])
    # Aggregate by movieId
    sent = df.groupby("movieId", as_index=False)["sentiment"].mean()
    return sent

# -------------------------------
# Recommendation Logic
# -------------------------------

def _title_to_ids(movies: pd.DataFrame, titles):
    title_set = {t.strip().lower() for t in titles}
    subset = movies[movies["title_clean"].str.lower().isin(title_set)]
    return subset["movieId"].tolist()

def recommend_hybrid(
    movies: pd.DataFrame,
    ratings: pd.DataFrame,
    liked_titles,
    preferred_genres=None,
    top_n: int = 5,
    alpha: float = 0.6,
    data_dir: Optional[Path] = None,
) -> pd.DataFrame:
    """
    Hybrid recommender combining item–item CF and content (genres).
    - liked_titles: list of movie titles (case-insensitive, year optional).
    - preferred_genres: optional list of genres to boost (e.g., ["Action","Comedy"]).
    - alpha: weight for CF (content gets 1 - alpha).
    Returns a DataFrame with recommended movies.
    """
    movies = clean_movies(movies)
    # Map liked titles to movieIds
    liked_ids = _title_to_ids(movies, liked_titles)
    if not liked_ids:
        raise ValueError("None of the liked titles matched MovieLens titles. Try removing the year or check spelling.")

    # Build item–item CF
    _, cf_sim = build_item_item_cf(ratings)

    # Build content similarity
    _, content_sim = build_content_vectors(movies, mode="tfidf")

    # Compute CF scores: mean similarity to liked items
    cf_scores = cf_sim.loc[:, liked_ids].mean(axis=1)  # average similarity to liked items
    cf_scores = cf_scores.rename("cf_score")

    # Compute content scores similarly
    content_scores = content_sim.loc[:, liked_ids].mean(axis=1)
    content_scores = content_scores.rename("content_score")

    # Combine
    scores = pd.concat([cf_scores, content_scores], axis=1).fillna(0.0)
    scores["hybrid"] = alpha * scores["cf_score"] + (1 - alpha) * scores["content_score"]

    # Optional: boost preferred genres
    if preferred_genres:
        preferred = {g.strip().lower() for g in preferred_genres}
        genre_boost = movies.set_index("movieId")["genres_list"].apply(lambda lst: 1.0 + 0.1 * sum(1 for g in (lst or []) if g.lower() in preferred))
        scores["hybrid"] = scores["hybrid"] * genre_boost.reindex(scores.index).fillna(1.0)

    # Optional: sentiment
    if data_dir is not None:
        sent = load_reviews_if_available(data_dir)
        if sent is not None and len(sent):
            sent = sent.set_index("movieId")["sentiment"]
            # Normalize sentiment to [0.9, 1.1] mild boost
            s = sent.clip(-1, 1)
            boost = 1.0 + 0.1 * ((s - s.min()) / (s.max() - s.min() + 1e-9) - 0.5)
            scores["hybrid"] = scores["hybrid"] * boost.reindex(scores.index).fillna(1.0)

    # Exclude liked movies from recommendations
    scores = scores.drop(index=liked_ids, errors="ignore")

    # Join titles
    out = movies.set_index("movieId").join(scores, how="inner").reset_index()
    out = out.sort_values("hybrid", ascending=False)

    # Return Top-N with helpful columns
    cols = ["movieId", "title", "genres", "cf_score", "content_score", "hybrid"]
    return out[cols].head(top_n)

def search_titles(movies: pd.DataFrame, query: str, limit: int = 20) -> pd.DataFrame:
    """
    Case-insensitive substring match on title.
    """
    movies = clean_movies(movies)
    q = query.strip().lower()
    subset = movies[movies["title"].str.lower().str.contains(q, na=False)]
    return subset[["movieId", "title", "genres"]].head(limit)

def load_dataframes(data_dir: Path):
    movies, ratings = ensure_movielens_data(data_dir)
    movies = clean_movies(movies)
    return movies, ratings
